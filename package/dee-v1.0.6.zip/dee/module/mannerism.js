const mannerisms = {
    "Phlegm": [
        "Easy going attitude",
        "Quietly stubborn",
        "Doesn’t want to be any trouble",
        "Avoid conflict",
        "Open to all the options",
        "Passive listener (I am listening!)",
        "Can’t we all just get along?",
        "Unevenly apportions work",
        "Watches others",
        "Avoids making decisions",
        "Always looking for the exits",
        "Easily amused"
    ],
    "Black Bile": [
        "Reserved",
        "Generally looks sad or upset",
        "It’s safer not to go alone",
        "Schedule orientated",
        "Hears negatives",
        "Avoids criticism",
        "Incredibly organised",
        "Difficult to please",
        "Suspicious",
        "Always with a flourish",
        "It’s always better to music",
        "Thrifty"
    ],
    "Yellow Bile": [
        "Eager to find out more",
        "Unreasonably ambitious",
        "Insistent (go on, go on…)",
        "Trustworthy",
        "Louder is better",
        "Always prepared",
        "Knows everything",
        "Unrepentent",
        "Self-sufficient (but not prepared)",
        "Not tired (but tired)",
        "Throws things, just to cope",
        "Unnecessarily competitive"
    ],
    "Blood": [
        "Disorganised",
        "Short attention span",
        "Wealthy in my friends",
        "Sudden emotional pendulum",
        "Credit where credit’s due",
        "Wants to please",
        "Unintentionally forgetful",
        "Open to being led astray",
        "Generally full of cheer",
        "Have gossip, will gossip",
        "Mildly immature",
        "Always tries to bounce back"
    ]
}

export function mannerism() {
    const humours = Object.keys(mannerisms);
    const humour = humours[Math.floor((Math.random() * humours.length))];
    const manner = mannerisms[humour][Math.floor((Math.random() * humour.length))];
    return {humour:humour,detail:manner};
}